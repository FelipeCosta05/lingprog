from flask_wtf import FlaskForm
from datetime import datetime
from wtforms import StringField, BooleanField, SubmitField, SelectField, IntegerField, RadioField
from wtforms.validators import ValidationError, DataRequired
from wtforms.fields.html5 import DateField

class Controle_Temperatura(FlaskForm):
    temperatura = IntegerField('Temperatura (ºC)', validators=[DataRequired()])
    umidade    = IntegerField('Umidade relativa do ar (%)', validators=[DataRequired()])
    atualizar   = SubmitField(' Atualizar')

class Parametros(FlaskForm):
    temperatura = IntegerField('Temperatura (ºC)', validators=[DataRequired()])
    kp          = IntegerField('Ganho Proporcional', validators=[DataRequired()])
    ti          = IntegerField('Ganho Integrativo', validators=[DataRequired()])
    kd          = IntegerField('Ganho Derivativo', validators=[DataRequired()])
    salvar      = SubmitField(' Salvar')