from flask import render_template, flash, redirect, url_for
from app import app
from app.forms import *
from flask import request
from werkzeug.urls import url_parse



@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', title='Home')

@app.route('/monitora', methods=['GET', 'POST'])
def monitora():
    form = Controle_Temperatura()
    if form.validate_on_submit():
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('monitora')
        return redirect(next_page)    
    return render_template('monitora.html', title='Monitoramento', form = form)    

@app.route('/config', methods=['GET', 'POST'])
def config():
    form = Parametros()
    if form.validate_on_submit():
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('config')
        return redirect(next_page)
    return render_template('config.html', title='Configurações', form = form)    